package com.config;

import java.io.FileWriter;
import java.io.IOException;

/* *

public class AlipayConfig {
}

