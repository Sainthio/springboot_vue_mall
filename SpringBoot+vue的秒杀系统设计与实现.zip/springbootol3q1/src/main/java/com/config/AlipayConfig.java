package com.config;

public class AlipayConfig {
    // TODO: Alipay config placeholder
}
