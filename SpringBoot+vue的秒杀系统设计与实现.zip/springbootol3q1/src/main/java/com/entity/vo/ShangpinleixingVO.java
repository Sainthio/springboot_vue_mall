package com.entity.vo;

import com.entity.ShangpinleixingEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;

public class ShangpinleixingVO  implements Serializable {
	private static final long serialVersionUID = 1L;

}
